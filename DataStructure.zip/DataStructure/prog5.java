import java.util.Scanner;
class prog5
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		DeQueue dequeue = new DeQueue();
		System.out.println("Enter the string.");
		String str = sc.next();

		char charBegin;
		char charEnd;

		//enque the elements
		for(int i=0;i<str.length();i++)
			dequeue.addFront(str.charAt(i));

		for(int i = 0;i<(str.length()/2);i++)
		{
			charBegin = dequeue.removeFront();
			charEnd = dequeue.removeRear();
			if(charBegin == charEnd){
				if(dequeue.size() == 0 || dequeue.size() == 1)
				{	
					System.out.println("Palindrome");
				}
				continue;
			}
			else
				break;
		}
		System.out.println("NOT Palindrome");
	}
}



class Node
{
	char ch;
	Node next;
	Node(char ch)
	{
		this.ch = ch;
		this.next = null;
	}
}


class DeQueue
{
	Node front, rear;
	DeQueue()
	{
		this.front = null;
		this.rear = null;
	}

	boolean isEmpty()
	{
		if(front ==  null)
			return true;
		return false;
	}

	void addFront(char c)
	{
		Node new_node = new Node(c);
		if(isEmpty())
		{
			front = new_node;
			rear = new_node;
		}
		else
		{
			new_node.next = front;
			front = new_node;
		}
		display();
	}

	char removeFront()
	{
		char frontChar;
		if(front == null){
			rear = null;
		}
		frontChar = front.ch;
		if((front.next == null) ||  (front == rear)){front = null; rear = null;}
		front = front.next;
		display();
		return frontChar;
	}

	char removeRear()
	{
		char rearChar;
		Node temp = front;
		if(rear == null)
		{
			front = null;
		}
		rearChar = rear.ch;
		if((rear == front) && (rear != null))
		{
			front = null;
			rear = null;
		}
		while(temp.next!=rear)
		{
			temp=temp.next;
		}
		rear = temp;
		display();
		return rearChar;
	}

	int size()
	{ 
		int count = 0;
		Node temp = front;
		if(front == rear)
		   return 1;
		while(temp != rear)
		{
			count++;
			temp = temp.next;
		}
		return count+1;
	}
	void display()
	{ 
		Node temp = front;
		while(temp != rear){
			System.out.print(temp.ch + "-->");
			temp = temp.next;
		}
		System.out.println(temp.ch);
	}
}