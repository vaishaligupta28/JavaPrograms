class test1
{
	public static void main(String args[])
	{
	Integer val = 222;
	String str = "hello";
        String str1 = "hello world"; 
	Float f = 2.34f;
	System.out.println(val.hashCode());
	System.out.println(str.hashCode());
	System.out.println(f.hashCode());
	}
}
